public class Guilda {

    private String nome;
    Personagem [] membros;

    public void guildaRaid (){


    }
    public void mostraInfo(){

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
