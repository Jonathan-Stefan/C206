package interfaces;

public interface Horda {

    public void forTheHorder();
    public void invadirAlliance();
}
