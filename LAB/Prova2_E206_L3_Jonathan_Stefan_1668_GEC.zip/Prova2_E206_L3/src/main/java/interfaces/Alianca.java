package interfaces;

public interface Alianca {

    public void ForTheAlliance();
    public void InvadirHorda();


}
