package interfaces;

public interface CombateCorpoACorpo {

    public void sacarArma();
}
