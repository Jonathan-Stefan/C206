package interfaces;

public interface CombateDistancia {

    public void castarSpell();
}
