public class Motor {

    double velocidadeMaxima;

    void mostraInfo(){
        System.out.println("A velocidade maxima do carro é: " +velocidadeMaxima);
    }
}
